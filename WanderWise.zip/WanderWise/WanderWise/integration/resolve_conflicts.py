import json
import csv
from pathlib import Path


# ---------------------------------------------------------
# PATHS
# ---------------------------------------------------------

BASE_DIR = Path(__file__).resolve().parent.parent

# Veera's matching results
MATCHING_FILE = (
    BASE_DIR
    / "data"
    / "member1_matching_results.csv"
)

# Santhosh's conflict detection results
# IMPORTANT:
# Your actual folder is "data engineering" with a SPACE.
CONFLICT_FILE = (
    BASE_DIR
    / "data engineering"
    / "output"
    / "conflict_detection_results.json"
)

# Final outputs created by this script
OUTPUT_DIR = (
    BASE_DIR
    / "data engineering"
    / "output"
)

OUTPUT_JSON = OUTPUT_DIR / "final_resolved_results.json"
OUTPUT_CSV = OUTPUT_DIR / "final_resolved_results.csv"


# ---------------------------------------------------------
# CONFIGURATION
# ---------------------------------------------------------

# 1 acre = 4046.8564224 square metres
SQM_PER_ACRE = 4046.8564224

# If Revenue and Survey differ by <= 5%,
# consider them consistent.
SOURCE_AGREEMENT_THRESHOLD = 5.0

# If geometry differs from declared area by > 5%,
# flag geometry for review.
GEOMETRY_CONFLICT_THRESHOLD = 5.0


# ---------------------------------------------------------
# HELPER FUNCTIONS
# ---------------------------------------------------------

def safe_float(value, default=0.0):
    """
    Safely convert a value to float.

    Empty strings, None, or invalid values
    return the default value instead of crashing.
    """
    if value is None:
        return default

    if isinstance(value, (int, float)):
        return float(value)

    value = str(value).strip()

    if value == "":
        return default

    try:
        return float(value)
    except (ValueError, TypeError):
        return default


def optional_float(value):
    """
    Convert a value to float.

    Returns None if the value is empty or invalid.
    """
    if value is None:
        return None

    if isinstance(value, (int, float)):
        return float(value)

    value = str(value).strip()

    if value == "":
        return None

    try:
        return float(value)
    except (ValueError, TypeError):
        return None


def sqm_to_acres(sqm):
    """Convert square metres to acres."""

    if sqm is None:
        return None

    try:
        return float(sqm) / SQM_PER_ACRE
    except (ValueError, TypeError):
        return None


def percentage_difference(value1, value2):
    """
    Calculate percentage difference between two values.
    """

    if value1 is None or value2 is None:
        return None

    if value1 == 0 and value2 == 0:
        return 0.0

    denominator = max(
        abs(value1),
        abs(value2)
    )

    if denominator == 0:
        return 0.0

    return (
        abs(value1 - value2)
        / denominator
        * 100
    )


# ---------------------------------------------------------
# LOAD VEERA'S MATCHING RESULTS
# ---------------------------------------------------------

def load_matching_results():
    """
    Load Veera's record-matching CSV.
    """

    if not MATCHING_FILE.exists():

        raise FileNotFoundError(
            "\nVeera's matching file was not found:\n"
            f"{MATCHING_FILE}\n\n"
            "Check that member1_matching_results.csv "
            "exists inside the data folder."
        )

    records = []

    with open(
        MATCHING_FILE,
        "r",
        encoding="utf-8-sig"
    ) as file:

        reader = csv.DictReader(file)

        for row in reader:
            records.append(row)

    return records


# ---------------------------------------------------------
# LOAD SANTHOSH'S CONFLICT RESULTS
# ---------------------------------------------------------

def load_conflict_results():
    """
    Load Santhosh's conflict detection JSON.
    """

    if not CONFLICT_FILE.exists():

        raise FileNotFoundError(
            "\nSanthosh's conflict file was not found:\n"
            f"{CONFLICT_FILE}\n\n"
            "Check that conflict_detection_results.json "
            "exists inside:\n"
            "data engineering/output/"
        )

    with open(
        CONFLICT_FILE,
        "r",
        encoding="utf-8"
    ) as file:

        data = json.load(file)

    return data


# ---------------------------------------------------------
# CREATE CONFLICT LOOKUP
# ---------------------------------------------------------

def create_conflict_lookup(conflicts):
    """
    Create a lookup table:

        survey_number -> conflict result
    """

    lookup = {}

    if not isinstance(conflicts, list):
        return lookup

    for conflict in conflicts:

        if not isinstance(conflict, dict):
            continue

        survey_number = conflict.get(
            "survey_number"
        )

        if survey_number:

            survey_number = str(
                survey_number
            ).strip()

            lookup[survey_number] = conflict

    return lookup


# ---------------------------------------------------------
# RESOLVE ONE PARCEL
# ---------------------------------------------------------

def resolve_parcel(match, conflict):
    """
    Combine Veera's matching result with Santhosh's
    conflict result and generate an explainable resolution.
    """

    survey_number = match.get(
        "survey_s_no"
    )

    if survey_number:
        survey_number = str(
            survey_number
        ).strip()

    # -----------------------------------------------------
    # READ REVENUE AREA
    # -----------------------------------------------------

    revenue_area = optional_float(
        match.get(
            "revenue_area_acres"
        )
    )

    # -----------------------------------------------------
    # READ SURVEY AREA
    # -----------------------------------------------------

    survey_area_sqm = optional_float(
        match.get(
            "survey_area_sqm"
        )
    )

    survey_area_acres = sqm_to_acres(
        survey_area_sqm
    )

    # -----------------------------------------------------
    # MATCHING SCORES
    # -----------------------------------------------------

    match_score = safe_float(
        match.get("match_score"),
        0.0
    )

    survey_score = safe_float(
        match.get("survey_score"),
        0.0
    )

    village_score = safe_float(
        match.get("village_score"),
        0.0
    )

    area_difference_percent = safe_float(
        match.get(
            "area_difference_percent"
        ),
        0.0
    )

    # -----------------------------------------------------
    # CASE 1: UNMATCHED RECORD
    # -----------------------------------------------------

    if match.get("status") != "MATCH":

        return {

            "parcel_id": None,

            "survey_number": survey_number,

            "status": "UNRESOLVED_MATCH",

            "resolution_type":
                "RECORD_MATCH_REVIEW",

            "matching": {

                "status":
                    match.get("status"),

                "match_score":
                    match_score,

                "survey_score":
                    survey_score,

                "village_score":
                    village_score,

                "area_difference_percent":
                    area_difference_percent
            },

            "source_data": {

                "revenue_area_acres":
                    revenue_area,

                "survey_area_sqm":
                    survey_area_sqm,

                "survey_area_acres":
                    survey_area_acres
            },

            "conflict": {

                "type":
                    "RECORD_MATCH_CONFLICT",

                "severity":
                    "HIGH",

                "description":
                    (
                        "No reliable survey record was "
                        "matched to this revenue record."
                    )
            },

            "resolution": {

                "harmonized_area_acres":
                    None,

                "recommended_action":
                    "MANUAL_RECORD_VERIFICATION_REQUIRED",

                "reason":
                    (
                        "The record could not be reliably "
                        "matched to a survey parcel. "
                        "The system must not automatically "
                        "merge unrelated records."
                    ),

                "status":
                    "PENDING_REVIEW"
            }
        }

    # -----------------------------------------------------
    # MATCHED PARCEL
    # -----------------------------------------------------

    parcel_id = None

    owners = []

    if conflict:

        parcel_id = conflict.get(
            "parcel_id"
        )

        owners = conflict.get(
            "owners",
            []
        )

    owner = None

    if owners:

        owner = owners[0]

    # -----------------------------------------------------
    # COMPARE REVENUE AND SURVEY
    # -----------------------------------------------------

    source_difference = percentage_difference(
        revenue_area,
        survey_area_acres
    )

    sources_agree = (

        source_difference is not None

        and

        source_difference
        <= SOURCE_AGREEMENT_THRESHOLD
    )

    # -----------------------------------------------------
    # EXTRACT GEOMETRY CONFLICT
    # -----------------------------------------------------

    geometry_area_acres = None

    geometry_difference = None

    geometry_conflict = False

    geometry_conflict_type = None

    if conflict:

        conflict_items = conflict.get(
            "conflicts",
            []
        )

        if isinstance(
            conflict_items,
            list
        ):

            for item in conflict_items:

                if not isinstance(
                    item,
                    dict
                ):
                    continue

                conflict_type = item.get(
                    "type"
                )

                if (
                    conflict_type
                    == "GEOMETRY_AREA_MISMATCH"
                ):

                    geometry_conflict_type = (
                        conflict_type
                    )

                    details = item.get(
                        "details",
                        {}
                    )

                    if not isinstance(
                        details,
                        dict
                    ):
                        details = {}

                    geometry_area_m2 = (
                        details.get(
                            "geometry_area_m2"
                        )
                    )

                    if geometry_area_m2 is not None:

                        geometry_area_acres = (
                            sqm_to_acres(
                                geometry_area_m2
                            )
                        )

                    geometry_difference = (
                        optional_float(
                            details.get(
                                "pct_difference"
                            )
                        )
                    )

                    if (
                        geometry_difference
                        is not None
                    ):

                        geometry_conflict = (
                            geometry_difference
                            > GEOMETRY_CONFLICT_THRESHOLD
                        )

    # -----------------------------------------------------
    # RESOLUTION LOGIC
    # -----------------------------------------------------

    if (
        sources_agree
        and
        geometry_conflict
    ):

        # Revenue and Survey independently agree.
        # Geometry is the outlier.

        if revenue_area is not None:

            harmonized_area = (
                revenue_area
            )

        else:

            harmonized_area = (
                survey_area_acres
            )

        resolution_type = (
            "RESOLVED_WITH_GEOMETRY_REVIEW"
        )

        resolution_status = (
            "RESOLVED_ATTRIBUTE_PENDING_GEOMETRY"
        )

        reason = (

            "Revenue and survey declared areas "
            "agree within "

            f"{SOURCE_AGREEMENT_THRESHOLD}% "

            "while the GIS geometry area differs "
            "significantly. The declared area is "
            "therefore retained as the harmonized "
            "attribute, while the GIS boundary is "
            "flagged for verification."
        )

        recommended_action = (
            "VERIFY_BOUNDARY_GEOMETRY"
        )

    elif sources_agree:

        # Revenue and Survey agree.
        # No significant geometry conflict.

        if revenue_area is not None:

            harmonized_area = (
                revenue_area
            )

        else:

            harmonized_area = (
                survey_area_acres
            )

        resolution_type = (
            "RESOLVED_BY_SOURCE_AGREEMENT"
        )

        resolution_status = (
            "RESOLVED"
        )

        reason = (

            "Revenue and survey declared areas "
            "agree within the "

            f"{SOURCE_AGREEMENT_THRESHOLD}% "

            "tolerance."
        )

        recommended_action = (
            "NO_IMMEDIATE_ACTION"
        )

    else:

        # Revenue and Survey disagree.
        # Do NOT guess which one is correct.

        harmonized_area = None

        resolution_type = (
            "UNRESOLVED_SOURCE_CONFLICT"
        )

        resolution_status = (
            "PENDING_REVIEW"
        )

        reason = (

            "Revenue and survey values do not "
            "agree sufficiently. The system cannot "
            "safely select one source automatically."
        )

        recommended_action = (
            "MANUAL_SOURCE_VERIFICATION_REQUIRED"
        )

    # -----------------------------------------------------
    # OWNER RESOLUTION
    # -----------------------------------------------------

    owner_resolution = None

    if owner:

        owner_resolution = {

            "harmonized_owner":
                owner,

            "source":
                "revenue/matched_record",

            "status":
                "RESOLVED_FROM_AVAILABLE_SOURCE"
        }

    # -----------------------------------------------------
    # DETECTED CONFLICT INFORMATION
    # -----------------------------------------------------

    conflict_detected = False

    original_severity = None

    conflict_types = []

    if conflict:

        conflict_detected = bool(
            conflict.get(
                "conflict_detected",
                False
            )
        )

        original_severity = (
            conflict.get(
                "overall_severity"
            )
        )

        conflict_items = conflict.get(
            "conflicts",
            []
        )

        if isinstance(
            conflict_items,
            list
        ):

            conflict_types = [

                item.get("type")

                for item in conflict_items

                if isinstance(
                    item,
                    dict
                )

                and item.get("type")
            ]

    # -----------------------------------------------------
    # FINAL RESULT
    # -----------------------------------------------------

    return {

        "parcel_id":
            parcel_id,

        "survey_number":
            survey_number,

        "status":
            resolution_status,

        "resolution_type":
            resolution_type,

        "matching": {

            "status":
                match.get("status"),

            "match_score":
                match_score,

            "survey_score":
                survey_score,

            "village_score":
                village_score,

            "area_difference_percent":
                area_difference_percent
        },

        "source_data": {

            "revenue_area_acres":
                revenue_area,

            "survey_area_sqm":
                survey_area_sqm,

            "survey_area_acres":
                survey_area_acres,

            "geometry_area_acres":
                geometry_area_acres
        },

        "evidence": {

            "revenue_survey_difference_percent":
                source_difference,

            "revenue_and_survey_agree":
                sources_agree,

            "geometry_conflict":
                geometry_conflict,

            "geometry_difference_percent":
                geometry_difference,

            "geometry_conflict_type":
                geometry_conflict_type
        },

        "owner_resolution":
            owner_resolution,

        "conflict": {

            "detected":
                conflict_detected,

            "original_severity":
                original_severity,

            "conflict_types":
                conflict_types
        },

        "resolution": {

            "harmonized_area_acres":
                harmonized_area,

            "recommended_action":
                recommended_action,

            "reason":
                reason,

            "geometry_status": (

                "REQUIRES_BOUNDARY_VERIFICATION"

                if geometry_conflict

                else

                "NO_GEOMETRY_CONFLICT"
            ),

            "status":
                resolution_status
        }
    }


# ---------------------------------------------------------
# MAIN PIPELINE
# ---------------------------------------------------------

def main():

    print("=" * 60)

    print(
        "LANDSYNC CONFLICT RESOLUTION"
    )

    print("=" * 60)

    # -----------------------------------------------------
    # CHECK PATHS
    # -----------------------------------------------------

    print("\n[PATH CHECK]")

    print(
        f"Matching file:\n{MATCHING_FILE}"
    )

    print(
        f"\nConflict file:\n{CONFLICT_FILE}"
    )

    print(
        f"\nOutput directory:\n{OUTPUT_DIR}"
    )

    # -----------------------------------------------------
    # LOAD MATCHING RESULTS
    # -----------------------------------------------------

    print(
        "\n[1] Loading Veera's matching results..."
    )

    matching_records = (
        load_matching_results()
    )

    print(
        f"    Loaded {len(matching_records)} "
        "matching records."
    )

    # -----------------------------------------------------
    # LOAD CONFLICT RESULTS
    # -----------------------------------------------------

    print(
        "\n[2] Loading Santhosh's conflict results..."
    )

    conflict_records = (
        load_conflict_results()
    )

    print(
        f"    Loaded {len(conflict_records)} "
        "conflict records."
    )

    # -----------------------------------------------------
    # CREATE LOOKUP
    # -----------------------------------------------------

    conflict_lookup = (
        create_conflict_lookup(
            conflict_records
        )
    )

    print(
        f"    Created lookup for "
        f"{len(conflict_lookup)} parcels."
    )

    # -----------------------------------------------------
    # RESOLVE
    # -----------------------------------------------------

    print(
        "\n[3] Resolving conflicts..."
    )

    final_results = []

    for match in matching_records:

        survey_number = match.get(
            "survey_s_no"
        )

        if survey_number:

            survey_number = str(
                survey_number
            ).strip()

        conflict = (
            conflict_lookup.get(
                survey_number
            )
        )

        result = resolve_parcel(
            match,
            conflict
        )

        final_results.append(
            result
        )

        print(

            f"    {survey_number}: "

            f"{result['resolution_type']}"
        )

    # -----------------------------------------------------
    # MAKE SURE OUTPUT DIRECTORY EXISTS
    # -----------------------------------------------------

    OUTPUT_DIR.mkdir(
        parents=True,
        exist_ok=True
    )

    # -----------------------------------------------------
    # SAVE JSON
    # -----------------------------------------------------

    print(
        "\n[4] Saving final JSON..."
    )

    with open(
        OUTPUT_JSON,
        "w",
        encoding="utf-8"
    ) as file:

        json.dump(

            final_results,

            file,

            indent=2,

            ensure_ascii=False
        )

    print(
        f"    Saved:\n    {OUTPUT_JSON}"
    )

    # -----------------------------------------------------
    # CREATE CSV SUMMARY
    # -----------------------------------------------------

    print(
        "\n[5] Creating CSV summary..."
    )

    csv_rows = []

    for result in final_results:

        resolution = result.get(
            "resolution",
            {}
        )

        source_data = result.get(
            "source_data",
            {}
        )

        evidence = result.get(
            "evidence",
            {}

        )

        matching = result.get(
            "matching",
            {}
        )

        conflict = result.get(
            "conflict",
            {}
        )

        csv_rows.append({

            "parcel_id":
                result.get(
                    "parcel_id"
                ),

            "survey_number":
                result.get(
                    "survey_number"
                ),

            "status":
                result.get(
                    "status"
                ),

            "resolution_type":
                result.get(
                    "resolution_type"
                ),

            "match_score":
                matching.get(
                    "match_score"
                ),

            "survey_score":
                matching.get(
                    "survey_score"
                ),

            "village_score":
                matching.get(
                    "village_score"
                ),

            "revenue_area_acres":
                source_data.get(
                    "revenue_area_acres"
                ),

            "survey_area_sqm":
                source_data.get(
                    "survey_area_sqm"
                ),

            "survey_area_acres":
                source_data.get(
                    "survey_area_acres"
                ),

            "geometry_area_acres":
                source_data.get(
                    "geometry_area_acres"
                ),

            "revenue_survey_difference_percent":
                evidence.get(
                    "revenue_survey_difference_percent"
                ),

            "geometry_difference_percent":
                evidence.get(
                    "geometry_difference_percent"
                ),

            "harmonized_area_acres":
                resolution.get(
                    "harmonized_area_acres"
                ),

            "recommended_action":
                resolution.get(
                    "recommended_action"
                ),

            "geometry_status":
                resolution.get(
                    "geometry_status"
                ),

            "conflict_detected":
                conflict.get(
                    "detected"
                ),

            "conflict_severity":
                conflict.get(
                    "original_severity"
                ),

            "conflict_types":
                ", ".join(
                    conflict.get(
                        "conflict_types",
                        []
                    )
                ),

            "resolution_reason":
                resolution.get(
                    "reason"
                )
        })

    if csv_rows:

        fieldnames = list(
            csv_rows[0].keys()
        )

        with open(
            OUTPUT_CSV,
            "w",
            newline="",
            encoding="utf-8"
        ) as file:

            writer = csv.DictWriter(

                file,

                fieldnames=fieldnames
            )

            writer.writeheader()

            writer.writerows(
                csv_rows
            )

    else:

        # Create an empty CSV with a basic header
        # if no records were processed.

        with open(
            OUTPUT_CSV,
            "w",
            newline="",
            encoding="utf-8"
        ) as file:

            writer = csv.writer(file)

            writer.writerow([
                "parcel_id",
                "survey_number",
                "status",
                "resolution_type"
            ])

    print(
        f"    Saved:\n    {OUTPUT_CSV}"
    )

    # -----------------------------------------------------
    # SUMMARY
    # -----------------------------------------------------

    resolved = sum(

        1

        for result in final_results

        if result["status"] in [

            "RESOLVED",

            "RESOLVED_ATTRIBUTE_PENDING_GEOMETRY"
        ]
    )

    pending = sum(

        1

        for result in final_results

        if (

            result["status"]
            == "PENDING_REVIEW"

            or

            result["status"]
            == "UNRESOLVED_MATCH"
        )
    )

    geometry_review = sum(

        1

        for result in final_results

        if (

            result.get("resolution", {})
            .get("geometry_status")

            == "REQUIRES_BOUNDARY_VERIFICATION"
        )
    )

    # -----------------------------------------------------
    # FINAL TERMINAL OUTPUT
    # -----------------------------------------------------

    print(
        "\n" + "=" * 60
    )

    print(
        "LANDSYNC RESOLUTION COMPLETE"
    )

    print(
        "=" * 60
    )

    print(
        f"\nTotal records       : "
        f"{len(final_results)}"
    )

    print(
        f"Resolved            : "
        f"{resolved}"
    )

    print(
        f"Pending review      : "
        f"{pending}"
    )

    print(
        f"Geometry review     : "
        f"{geometry_review}"
    )

    print(
        "\nJSON output:"
    )

    print(
        OUTPUT_JSON
    )

    print(
        "\nCSV output:"
    )

    print(
        OUTPUT_CSV
    )

    print(
        "\nNext step:"
    )

    print(
        "Open final_resolved_results.json "
        "and final_resolved_results.csv "
        "to verify the results."
    )


# ---------------------------------------------------------
# RUN PROGRAM
# ---------------------------------------------------------

if __name__ == "__main__":
    main()
from pathlib import Path
import csv
import json


# ============================================================
# LANDSYNC
# Veera + Priya → Santhosh Conflict Engine Integration
# ============================================================

BASE_DIR = Path(__file__).resolve().parent.parent

# Input from your matching module
MATCHING_FILE = BASE_DIR / "data" / "member1_matching_results.csv"

# Priya's standardized revenue data
REVENUE_FILE = BASE_DIR / "data" / "dept_revenue.csv"

# Priya/Fahim survey geometry data
SURVEY_FILE = BASE_DIR / "data" / "dept_survey.geojson"

# Santhosh's data folder
OUTPUT_DIR = BASE_DIR / "data engineering" / "data"

# Final JSON passed to Santhosh's conflict engine
OUTPUT_FILE = OUTPUT_DIR / "member1_matched_records.json"


# ------------------------------------------------------------
# Utility functions
# ------------------------------------------------------------

def load_csv(file_path):
    """Load CSV data as a list of dictionaries."""
    with open(file_path, "r", encoding="utf-8-sig", newline="") as file:
        return list(csv.DictReader(file))


def load_json(file_path):
    """Load JSON/GeoJSON data."""
    with open(file_path, "r", encoding="utf-8-sig") as file:
        return json.load(file)


def clean_text(value):
    """Safely convert values to stripped strings."""
    if value is None:
        return ""

    return str(value).strip()


def find_column(row, possible_names):
    """
    Find the first available column from a list of possible names.
    Makes the integration more tolerant of slightly different schemas.
    """
    for name in possible_names:
        if name in row:
            value = row.get(name)

            if value is not None and str(value).strip() != "":
                return value

    return None


def find_survey_feature(features, survey_number):
    """
    Find a survey GeoJSON feature using its survey number.
    Supports a few common property-name variations.
    """

    target = clean_text(survey_number).lower()

    for feature in features:
        properties = feature.get("properties", {})

        candidate = find_column(
            properties,
            [
                "s_no",
                "S_No",
                "survey_no",
                "SurveyNo",
                "survey_number",
                "Survey_Number",
            ],
        )

        if candidate is None:
            continue

        if clean_text(candidate).lower() == target:
            return feature

    return None


def format_area(value, unit):
    """
    Convert an area value into the common 'area' field expected
    by Santhosh's conflict detector.
    """

    if value is None or clean_text(value) == "":
        return None

    return f"{clean_text(value)} {unit}"


# ------------------------------------------------------------
# Main integration
# ------------------------------------------------------------

def build_integrated_dataset():

    print("=" * 70)
    print("LANDSYNC - BUILDING CONFLICT INPUT")
    print("=" * 70)

    # --------------------------------------------------------
    # Validate input files
    # --------------------------------------------------------

    required_files = [
        MATCHING_FILE,
        REVENUE_FILE,
        SURVEY_FILE,
    ]

    for file_path in required_files:
        if not file_path.exists():
            raise FileNotFoundError(
                f"Required file not found:\n{file_path}"
            )

    # --------------------------------------------------------
    # Load datasets
    # --------------------------------------------------------

    matching_rows = load_csv(MATCHING_FILE)
    revenue_rows = load_csv(REVENUE_FILE)
    survey_data = load_json(SURVEY_FILE)

    survey_features = survey_data.get("features", [])

    print(f"\nMatching rows found: {len(matching_rows)}")
    print(f"Revenue rows found: {len(revenue_rows)}")
    print(f"Survey features found: {len(survey_features)}")

    # --------------------------------------------------------
    # Create lookup map for revenue records
    # --------------------------------------------------------

    revenue_map = {}

    for row in revenue_rows:

        survey_number = find_column(
            row,
            [
                "SurveyNo",
                "survey_no",
                "survey_number",
                "S_No",
            ],
        )

        if survey_number is None:
            continue

        revenue_map[clean_text(survey_number)] = row

    # --------------------------------------------------------
    # Build unified parcels
    # --------------------------------------------------------

    parcels = []

    for index, match in enumerate(matching_rows, start=1):

        revenue_survey = clean_text(
            find_column(
                match,
                [
                    "revenue_survey",
                    "RevenueSurvey",
                    "survey_number",
                    "SurveyNo",
                ],
            )
        )

        survey_s_no = clean_text(
            find_column(
                match,
                [
                    "survey_s_no",
                    "survey_no",
                    "survey_number",
                    "S_No",
                ],
            )
        )

        status = clean_text(
            find_column(
                match,
                [
                    "status",
                    "matching_status",
                ],
            )
        ).upper()

        match_score_raw = find_column(
            match,
            [
                "match_score",
                "matching_score",
            ],
        )

        survey_score_raw = find_column(
            match,
            [
                "survey_score",
            ],
        )

        village_score_raw = find_column(
            match,
            [
                "village_score",
            ],
        )

        area_difference_raw = find_column(
            match,
            [
                "area_difference_percent",
            ],
        )

        # ----------------------------------------------------
        # Skip unmatched rows
        # ----------------------------------------------------

        if status == "UNMATCHED":

            print(
                f"[SKIP] Row {index}: "
                f"{revenue_survey or survey_s_no} -> UNMATCHED"
            )

            continue

        # ----------------------------------------------------
        # Find revenue record
        # ----------------------------------------------------

        revenue_record = revenue_map.get(revenue_survey)

        if revenue_record is None:

            print(
                f"[SKIP] Row {index}: "
                f"No revenue record found for {revenue_survey}"
            )

            continue

        # ----------------------------------------------------
        # Find survey geometry
        # ----------------------------------------------------

        survey_feature = find_survey_feature(
            survey_features,
            survey_s_no or revenue_survey,
        )

        if survey_feature is None:

            print(
                f"[SKIP] Row {index}: "
                f"No survey geometry found for "
                f"{survey_s_no or revenue_survey}"
            )

            continue

        survey_properties = survey_feature.get(
            "properties",
            {},
        )

        survey_geometry = survey_feature.get(
            "geometry"
        )

        # ----------------------------------------------------
        # Revenue attributes
        # ----------------------------------------------------

        revenue_area = find_column(
            revenue_record,
            [
                "Land_Area_Acres",
                "area_acres",
                "Area_Acres",
                "area",
            ],
        )

        revenue_owner = find_column(
            revenue_record,
            [
                "Patta_Holder",
                "owner_name",
                "Owner_Name",
                "owner",
            ],
        )

        revenue_village = find_column(
            revenue_record,
            [
                "Revenue_Village",
                "village",
                "Village",
            ],
        )

        revenue_survey_number = find_column(
            revenue_record,
            [
                "SurveyNo",
                "survey_no",
                "survey_number",
                "S_No",
            ],
        )

        # ----------------------------------------------------
        # Survey attributes
        # ----------------------------------------------------

        survey_area_sqm = find_column(
            survey_properties,
            [
                "extent_sqm",
                "area_sqm",
                "Extent_Sqm",
                "area",
            ],
        )

        survey_owner = find_column(
            survey_properties,
            [
                "owner_name",
                "Owner_Name",
                "owner",
                "Patta_Holder",
            ],
        )

        survey_village = find_column(
            survey_properties,
            [
                "village",
                "Village",
                "Survey_Village",
            ],
        )

        survey_survey_number = find_column(
            survey_properties,
            [
                "s_no",
                "S_No",
                "survey_no",
                "survey_number",
                "SurveyNo",
            ],
        )

        # ----------------------------------------------------
        # Build Revenue source record
        #
        # IMPORTANT:
        # Santhosh's detector expects the common field:
        #     area
        # not:
        #     area_acres
        # ----------------------------------------------------

        revenue_source_record = {
            "source": "revenue",
            "survey_number": clean_text(
                revenue_survey_number or revenue_survey
            ),
            "village": clean_text(
                revenue_village
            ),
            "area": format_area(
                revenue_area,
                "acre"
            ),
            "owner_name": (
                clean_text(revenue_owner)
                if revenue_owner is not None
                else None
            ),
        }

        # ----------------------------------------------------
        # Build Survey source record
        # ----------------------------------------------------

        survey_source_record = {
            "source": "survey",
            "survey_number": clean_text(
                survey_survey_number or survey_s_no or revenue_survey
            ),
            "village": clean_text(
                survey_village
            ),
            "area": format_area(
                survey_area_sqm,
                "sq_m"
            ),
            "owner_name": (
                clean_text(survey_owner)
                if survey_owner is not None
                else None
            ),
        }

        # ----------------------------------------------------
        # Matching metadata
        # ----------------------------------------------------

        try:
            match_score = float(match_score_raw)
        except (TypeError, ValueError):
            match_score = 0.0

        try:
            survey_score = float(survey_score_raw)
        except (TypeError, ValueError):
            survey_score = 0.0

        try:
            village_score = float(village_score_raw)
        except (TypeError, ValueError):
            village_score = 0.0

        try:
            area_difference_percent = float(
                area_difference_raw
            )
        except (TypeError, ValueError):
            area_difference_percent = None

        # ----------------------------------------------------
        # Parcel ID
        # ----------------------------------------------------

        parcel_id = f"LS-{len(parcels) + 1:03d}"

        # ----------------------------------------------------
        # Create unified parcel
        # ----------------------------------------------------

        parcel = {
            "parcel_id": parcel_id,

            "matched_records": [
                revenue_source_record,
                survey_source_record,
            ],

            "cadastral_geometry": survey_geometry,

            "survey_geometry": survey_geometry,

            "temporal_snapshots": [],

            "metadata": {
                "match_score": match_score,
                "survey_score": survey_score,
                "village_score": village_score,
                "area_difference_percent": area_difference_percent,
                "matching_status": status,
                "integration_source": (
                    "Veera Record Matching + "
                    "Priya Dataset Collection"
                ),
            },
        }

        parcels.append(parcel)

        print(
            f"[ADD] {parcel_id} | "
            f"{revenue_survey} | "
            f"match={match_score}"
        )

    # --------------------------------------------------------
    # Final LandSync dataset
    # --------------------------------------------------------

    dataset = {
        "project_name": "LandSync",
        "region": "Thiruvanmiyur",
        "source": "Veera Parcel Matching + Priya Dataset Collection",
        "parcels": parcels,
    }

    return dataset


# ------------------------------------------------------------
# Save output
# ------------------------------------------------------------

def main():

    try:

        dataset = build_integrated_dataset()

        OUTPUT_DIR.mkdir(
            parents=True,
            exist_ok=True
        )

        with open(
            OUTPUT_FILE,
            "w",
            encoding="utf-8"
        ) as file:

            json.dump(
                dataset,
                file,
                indent=2,
                ensure_ascii=False
            )

        print("\n" + "=" * 70)
        print("SUCCESS")
        print("=" * 70)

        print(
            f"\nMatched parcels created: "
            f"{len(dataset['parcels'])}"
        )

        print(
            "\nOutput file:"
        )

        print(
            OUTPUT_FILE.resolve()
        )

        print("=" * 70)

    except Exception as error:

        print("\n" + "=" * 70)
        print("ERROR")
        print("=" * 70)

        print(
            f"\n{type(error).__name__}: {error}"
        )

        raise


if __name__ == "__main__":
    main()